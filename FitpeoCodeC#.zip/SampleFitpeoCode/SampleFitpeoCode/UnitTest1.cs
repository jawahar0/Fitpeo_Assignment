using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Runtime.ConstrainedExecution;

namespace SampleFitpeoCode
{
    public class Tests
    {

        [Test]
        public void Test1()
        {
            //Launching the browser and load the url
            IWebDriver driver = new ChromeDriver();
            driver.Url = "https://fitpeo.com/";
            driver.Manage().Window.Maximize();

            //Wait condition is used for find the elements
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            //Clicking the Revenue Calculator
            wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText("Revenue Calculator")));
            IWebElement revenueCalendarLink = driver.FindElement(By.LinkText("Revenue Calculator"));
            revenueCalendarLink.Click();

            //Scroll the page into the Medicare Eligible Patients textlabel
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//h4[contains(text(),'Medicare Eligible Patients')]")));
            IWebElement scrollMedicareEligiblePatients = driver.FindElement(By.XPath("//h4[contains(text(),'Medicare Eligible Patients')]"));
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("arguments[0].scrollIntoView(true)", scrollMedicareEligiblePatients);


            //Adjust the slider
            Actions act = new Actions(driver);
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//input[@type='number']"))).Clear();
            IWebElement patientTextfield = driver.FindElement(By.XPath("//input[@type='number']"));
            act.Click(patientTextfield).KeyDown(Keys.Control).SendKeys("a").KeyUp(Keys.Control).SendKeys(Keys.Delete).Build().Perform();
            driver.FindElement(By.XPath("//input[@type='number']")).SendKeys("820");

            //Update the textfield
            act.Click(patientTextfield).KeyDown(Keys.Control).SendKeys("a").KeyUp(Keys.Control).SendKeys(Keys.Delete).Build().Perform();
            var slider = driver.FindElement(By.XPath("//input[@type='number']"));
            slider.SendKeys("560");

            //Validate Slider value
            string actual_valueOfPatientTextfield = slider.GetAttribute("value");
            Assert.That(actual_valueOfPatientTextfield, Is.EqualTo("560"));

            act.Click(patientTextfield).KeyDown(Keys.Control).SendKeys("a").KeyUp(Keys.Control).SendKeys(Keys.Delete).Build().Perform();
            var defaulltRestoreValue = driver.FindElement(By.XPath("//input[@type='number']"));
            defaulltRestoreValue.SendKeys("820");
           
            //Select CPT Codes
            for (int i = 1; i <= 3; i++)
            {
                driver.FindElement(By.XPath($"(//input[contains(@type,'checkbox')])[{i}]")).Click();
            }
            driver.FindElement(By.XPath("(//input[contains(@type,'checkbox')])[8]")).Click();

            //validating total recurring reimbursement and Verify the header total recurring reimbursement for all patients per Month
            string actualValueTotalRecurringReimbursementPatients = driver.FindElement(By.XPath("(//p[@class='MuiTypography-root MuiTypography-body1 inter css-hocx5c'])[4]")).Text;
            Assert.That(actualValueTotalRecurringReimbursementPatients, Is.EqualTo("$110700"));

            driver.Quit();






        }
    }
}