package fitpeo;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RevenueCalculator {
	
//	Download and Install Java 8 or higher version. Download and configure Eclipse or any Java IDE of your choice. Download Selenium WebDriver Java Client. Configure Selenium WebDriver

	public static void main(String[] args) throws InterruptedException, AWTException {
		System.setProperty("webdriver.edge.driver", "C:\\Users\\JAWAHAR\\eclipse-workspace\\SeleniumLearn\\drivers\\msedgedriver.exe");
		EdgeDriver driver = new EdgeDriver();
		driver.get("https://www.fitpeo.com/");
		driver.manage().window().maximize();
		driver.findElementByXPath("//div[text()='Revenue Calculator']").click();
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary css-sy3s50']")));
		WebElement patientsCount = driver.findElementByXPath("//span[@class='MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary css-sy3s50']");			
	    Actions act = new Actions(driver);
	    act.dragAndDropBy(patientsCount, 93, 0).perform();	    
	    Robot r = new Robot();
	    for (int i = 0; i < 3; i++) {
			r.keyPress(KeyEvent.VK_UP);
			r.keyRelease(KeyEvent.VK_UP);
		}
	    WebElement sliderValue = driver.findElementByXPath("//input[@class='MuiInputBase-input MuiOutlinedInput-input MuiInputBase-inputSizeSmall css-1o6z5ng']");
	    String attribute = sliderValue.getAttribute("value");
	    System.out.println(attribute);
	    act.click(sliderValue).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.DELETE).build().perform();
	    WebElement enterSliderValue = driver.findElementByXPath("//input[@type='number']");
	    enterSliderValue.sendKeys("560");
	    Thread.sleep(2000);
	    act.click(enterSliderValue).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.DELETE).build().perform();
	    enterSliderValue.sendKeys("820");
	    driver.findElementByXPath("(//input[@type='checkbox'])[1]").click();
	    driver.findElementByXPath("(//input[@type='checkbox'])[2]").click();
	    driver.findElementByXPath("(//input[@type='checkbox'])[3]").click();
	    driver.findElementByXPath("(//input[@type='checkbox'])[8]").click();
	    WebElement validateReimbursement = driver.findElementByXPath("(//p[@class='MuiTypography-root MuiTypography-body1 inter css-hocx5c'])[4]");
	    String text = validateReimbursement.getText();
	    System.out.println(text);
	    driver.quit();
	}
}